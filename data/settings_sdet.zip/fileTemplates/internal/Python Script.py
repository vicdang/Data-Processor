# -*- coding: utf-8 -*-
# vim:ts=3:sw=3:expandtab
"""
---------------------------
Copyright (C) ${YEAR}
@Authors: ${USER}
@Date: ${DATE}
@Version: 1.0
---------------------------
 Usage example:
   - ${FILE_NAME} <options>

"""

def main(args):
   return

if __name__ == '__main__':
   args = None
   main(args)
